import threading
import time
import redis

CHANNEL = 'test_channel'

def subscriber():
    r = redis.Redis(host='localhost', port=6379, decode_responses=True)  # Garnetのデフォルトポート
    pubsub = r.pubsub()
    pubsub.subscribe(CHANNEL)
    print(f"[Subscriber] Subscribed to '{CHANNEL}'")

    for message in pubsub.listen():
        if message['type'] == 'message':
            print(f"[Subscriber] Received: {message['data']}")

def publisher():
    r = redis.Redis(host='localhost', port=6379, decode_responses=True)
    for i in range(5):
        msg = f"Message {i}"
        r.publish(CHANNEL, msg)
        print(f"[Publisher] Sent: {msg}")
        time.sleep(1)

if __name__ == "__main__":
    sub_thread = threading.Thread(target=subscriber, daemon=True)
    sub_thread.start()

    time.sleep(1)  # 少し待ってからパブリッシュ開始
    publisher()

    time.sleep(2)  # メッセージ受信のため少し待機
    print("Done.")
