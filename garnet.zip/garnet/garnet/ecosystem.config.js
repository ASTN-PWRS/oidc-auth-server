module.exports = {
  apps: [
    {
      name: "garnet",
      script: "GarnetServer.exe",
      args: "--config-import-path ./garnet.conf",
      cwd: "./", // GarnetServer.exe のあるディレクトリ
      interpreter: "none",
      watch: false,
      autorestart: true,
      out_file: "./logs/garnet-out.log",
      error_file: "./logs/garnet-error.log",
      log_date_format: "YYYY-MM-DD HH:mm:ss",
    },
  ],
};
